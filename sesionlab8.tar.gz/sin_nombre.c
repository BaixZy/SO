#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/wait.h>


void error_and_exit (char *msg) {
  perror(msg);
  exit(1);
}

int main() {
    char buff[256];
    int pipefd[2];

    if (pipe(pipefd) < 0) {
        error_and_exit("Error pipe\n");
    }

    int pid = fork();
    if (pid < 0) {
        error_and_exit("Error fork\n");
    }
    else if (pid == 0) {                        // hijo
        close(0);
        dup(pipefd[0]);
        close(pipefd[1]);
        execlp("cat", "cat");
        error_and_exit("Error execlp\n");
    }
    else {                                      // padre
        sprintf(buff, "Inicio\n");
        write(pipefd[1], buff, strlen(buff));
        close(pipefd[1]);
        waitpid(pid, NULL, 0);
        sprintf(buff, "Fin\n");
        write(1, buff, strlen(buff));
    }
}
