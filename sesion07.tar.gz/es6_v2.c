#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <errno.h>


void fsignal(int s) {
  if (s == SIGINT) {
    char buf[128];
    sprintf(buf, "He recibido SIGINT\n");
    write(1, buf, strlen(buf));
  }
}


int main ()
{
  struct sigaction sa;
  sa.sa_handler = &fsignal;
  sa.sa_flags = SA_RESTART;
  sigemptyset(&sa.sa_mask);
  sigaction(SIGINT, &sa, NULL);

  char c;

  char buf[256];
  int ret = read (0, &c, sizeof (char));
  if (ret < 0) {
    if (errno == EINTR) sprintf(buf, "read interrumpido por signal\n");
    else sprintf(buf, "read con error\n");
  }
  else sprintf(buf, "read correcto\n");
  write(1, buf, strlen(buf));

  write (1, &c, sizeof (char));

}
