#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

void Usage() {
	char buf[] = "Usage:words arg1\nEste programa escribe el número de palabras del parámetro que recibe\n";
	write(1, buf, strlen(buf));
    exit(0);
}

int main(int argc, char *argv[]) {
    if (argc > 2) Usage();
    char *string = argv[1];
    int c = 1;
    int i = 0;
    unsigned char marca = 0;
    while (string[i] != '\0') {
        if (string[i] == ' ' || string[i] == '.' || string[i] == ',' || string[i] == '\n') marca = 1;
        else if (marca == 1) {
                ++c;
                marca = 0;
        }
        ++i;
    }
    char buff[100];
    sprintf(buff, "%d palabras\n", c);
    write(1, buff, strlen(buff));
}
