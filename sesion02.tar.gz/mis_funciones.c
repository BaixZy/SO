#include "mis_funciones.h"

void Usage() {
	char buf[] = "Usage:suma arg1 arg2 [arg3..argN]\nEste programa escribe la suma de los números que recibe\n";
	write(1, buf, strlen(buf));
}

int esNumero(char *str) {
  if (str != NULL) {
    int l = strlen(str);
    int i;

    if (str[0] == '-') {
	  if (l > MAX_SIZE + 1) return 0;
	  else i = 1;
	}
    else if (l > MAX_SIZE) return 0;
        else i = 0;


    while (str[i] >= '0' && str[i] <= '9') ++i;

    if (str[i]=='\0') return 1;
    else return 0;
  }
  else return 0;
}


unsigned int char2int(char c) {
  return (int)c - (int)'0';
}


int mi_atoi(char *s) {
  int l = strlen(s);
  int n = 0;
  if (s[0] == '-') {
    for (int i = 1; i < l; ++i) {
      n = 10*n - char2int(s[i]);
    }
  }
  else {
    for (int i = 0; i < l; ++i) {
      n = 10*n + char2int(s[i]);
    }
  }
  return n;
}
