#include "mis_funciones.h"


int main (int argc, char *argv[])
{
  char buf[80];
  int error = 0;
  int suma = 0;
  if (argc < 3) Usage();
  else {
    for (int i = 1; i < argc; ++i) {
      if (esNumero(argv[i]) == 0) {
        sprintf(buf, "Error: el parámetro “%s” no es un número\n", argv[i]);
        write(1, buf, strlen(buf));
        error = 1;
      }
      else if (error == 0) {
        suma = suma + mi_atoi(argv[i]);
      }
    }
    if (error == 0) {
      sprintf(buf, "La suma es %d\n", suma);
      write(1, buf, strlen(buf));
    }
  }
  return 0;
}
