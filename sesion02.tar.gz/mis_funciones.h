#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>

#define MAX_SIZE 9		// 8 xifres + '/0'

void Usage();

// Devuelve 1 si *str representa un número y tiene como mucho 8 cifras y 0 en cualquier otro caso
int esNumero (char *str);

// Pre: c>='0' && c<='9'
// Post: devuelve el número correspondiente
unsigned int char2int(char c);

// Pre: s != NULL
// Post: devuelve el int correspondiente a s. Si s no contiene un número correcto; el resultado es indefinido
int mi_atoi(char *s);
