#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>


void error_y_exit(char *msg,int exit_status) {
    perror(msg);
    exit(exit_status);
}

int main (int argc,char *argv[]) {
    char buffer [80];

    int pid = fork();
    switch (pid) {
      case 0:
        execlp("/dades/victor.otero.monzo/SO/S3/listaParametros", "listaParametros", "a", "b", (char*) NULL);
        error_y_exit("Error execlp", 1);
        break;

      case -1:
        error_y_exit("Error en fork",1);
        break;
    }
    pid = fork();
    switch (pid) {
      case 0:
        execlp("/dades/victor.otero.monzo/SO/S3/listaParametros", "listaParametros", (char*) NULL);
        error_y_exit("Error execlp", 1);
        break;

      case -1:
        error_y_exit("Error en fork",1);
        break;
    }
    pid = fork();
    switch (pid) {
      case 0:
        execlp("/dades/victor.otero.monzo/SO/S3/listaParametros", "listaParametros", "25", "4", (char*) NULL);
        error_y_exit("Error execlp", 1);
        break;

      case -1:
        error_y_exit("Error en fork",1);
        break;
    }
    pid = fork();
    switch (pid) {
      case 0:
        execlp("/dades/victor.otero.monzo/SO/S3/listaParametros", "listaParametros", "1024", "hola", "adios", (char*) NULL);
        error_y_exit("Error execlp", 1);
        break;

      case -1:
        error_y_exit("Error en fork",1);
        break;
    }

    waitpid(pid, NULL, 0);
}
