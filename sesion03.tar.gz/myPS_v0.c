#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>

int main (int argc,char *argv[]) {
    char buffer [80];
    int pid = fork();

    switch (pid)
    {
    case 0:
      sprintf (buffer, "HIJO: Soy el proceso %d y he recibido el parametro %s\n", getpid (), argv[1]);
      write (1, buffer, strlen (buffer));
      break;

    case -1:
      perror("Error en fork");
      exit(0);
      break;

    default:
      sprintf (buffer, "PADRE: Soy el proceso %d\n", getpid ());
      write (1, buffer, strlen (buffer));
    }
    while(1);
}
