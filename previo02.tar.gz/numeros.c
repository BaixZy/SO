#include <string.h>
#include <stdio.h>
#include <unistd.h>


const int MAX_SIZE = 8;

int
es_Numero (char *str)
{

  if (str == NULL)
    return 0;
  int n_cifras = strlen (str);
  if (n_cifras == 1 && str[0] == '-')
    return 0;
  if (str[0] != '-' && n_cifras > MAX_SIZE)
    return 0;
  if (str[0] == '-' && n_cifras > MAX_SIZE + 1)
    return 0;
  return 1;
}

int
main (int argc, char *argv[])
/*argc = entero que contiene el número de elementos de la array argv.
argv = array de strings que contiene los parámetros de entrada
*/
{
  char buf[128];
  for (int i = 0; i < argc; i++)
    {
      if (es_Numero (argv[i]) == 0)
	{
	  sprintf (buf, "%s no es número \n", argv[i]);
	}
      else
	{
	  sprintf (buf, "%s si es número\n", argv[i]);
	}
      write (1, buf, strlen (buf));
    }
  return 0;
}
