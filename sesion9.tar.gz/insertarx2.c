#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>

void errorExit(char* msg) {
    char buf[128];
    sprintf(buf, "Error en %s", msg);
    write(1, buf, strlen(buf));
    exit(-1);
}

int main(int argc, char* argv[]) {
    int fd = open("./f", O_RDWR);
    if (fd < 0) errorExit("open");

    struct stat st;
    fstat(fd, &st);
    int fsize = st.st_size;
    char *b = (char *)malloc(fsize - 2);
    if (lseek(fd, 3, SEEK_SET) < 0) errorExit("lseek");
    if (read(fd, b, fsize) < 0) errorExit("read");

    char c = 'X';
    if (lseek(fd, 3, SEEK_SET) < 0) errorExit("lseek");
    if (write(fd, &c, 1) < 0) errorExit("write");
    if (write(fd, b, strlen(b)) < 0) errorExit("write");
}
