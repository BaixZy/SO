#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>

int main(int argc, char* argv[]) {
    int fd = open("./file", O_RDONLY);
    int fd2 = open("./file.inv", O_CREAT | O_WRONLY | O_TRUNC);
    char c;
    int i = 2;
    lseek(fd, -1, SEEK_END);
    while (read(fd, &c, 1) > 0) {
        lseek(fd, -i, SEEK_END);
        write(fd2, &c, 1);
        ++i;
    }
    close(fd);
    close(fd2);
}
