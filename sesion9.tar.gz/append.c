#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>

int main(int argc, char* argv[]) {
    int fd = open("./file", O_RDWR);
    struct stat st;
    fstat(fd, &st);
    int fsize = st.st_size;
    char *buf = (char *)malloc(fsize);
    read(fd, buf, fsize);
    write(fd, buf, strlen(buf));
    free(buf);
    close(fd);
}
