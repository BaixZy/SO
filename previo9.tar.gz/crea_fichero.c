#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>

void errorExit(char* msg) {
    char buf[128];
    sprintf(buf, "Error en %s", msg);
    write(1, buf, strlen(buf));
    exit(-1);
}

int main(int argc, char* argv[]) {
    int fd = creat("./salida.txt", S_IRUSR | S_IWUSR);
    if (fd < 0) errorExit("creat");
    char buf [16];
    strcpy(buf, "ABCD");
    if (write(fd, buf, strlen(buf)) < 0) errorExit("write");
}
