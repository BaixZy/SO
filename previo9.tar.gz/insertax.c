#include <stdlib.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

void errorExit(char* msg) {
    char buf[128];
    sprintf(buf, "Error en %s", msg);
    write(1, buf, strlen(buf));
    exit(-1);
}

int main(int argc, char* argv[]) {
    int fd = open("./salida.txt", O_RDWR);
    if (fd < 0) errorExit("open");
    if (lseek(fd, -1, SEEK_END) < 0) errorExit("lseek"); //1 byte antes del final del archivo.
    char b1[2];
    char b2[3];
    if (read(fd, b1, 1) < 0) errorExit("read"); //b1 contiene el último byte.
   
    b2[0] = 'X';
    b2[1] = b1[0];
    b2[2] = '\0';
    if (lseek(fd, -1, SEEK_END) < 0) errorExit("lseek"); //1 byte antes del final del archivo.
    if (write(fd, b2, 2) < 0) errorExit("write");
}
