#include <stdio.h>
#include <signal.h>
#include <stdlib.h>
#include <string.h>
#include<unistd.h>

#define REGION_SIZE		4096

int *p;

void f_signal(int s) {
    if (s == SIGSEGV) {
        char buff[256];
        sprintf (buff, "\tProgram code -- p address: %p, p value: %p, @Fin_heap: %d\n",
               &p, p, sbrk(0));
        write (1, buff, strlen (buff));
        exit(0);
    }
}

int main (int argc, char *argv[])
{
  int i = 0;
  char buff[256];
  struct sigaction t;
  t.sa_handler = f_signal;
  sigemptyset(&t.sa_mask);
  t.sa_flags = 0;
  sigaction(SIGSEGV, &t, NULL);

  sprintf (buff, "Addresses:\n");
  write (1, buff, strlen (buff));
  sprintf (buff, "\tp: %p\n", &p);
  write (1, buff, strlen (buff));

  p = malloc (sizeof (int));

  if (p == NULL)
    {
      sprintf (buff, "ERROR en el malloc\n");
      write (2, buff, strlen (buff));
    }

  while (p < sbrk(0))
    {
      *p = i;
      sprintf (buff, "\tProgram code -- p address: %p, p value: %p, *p: %d\n",
               &p, p, *p);
      write (1, buff, strlen (buff));
      p++;
      i++;
    }
}
