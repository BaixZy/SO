#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include "socketMng.h"


#define buff_size 256


void error_and_exit (char *msg) {
    perror(msg);
    exit(1);
}

int main() {
    int socketFD;
    int connectionFD;
    char buffer[buff_size];
    int ret;
    char * id = "socket1";
    socketFD = createSocket(id);
    if (socketFD < 0)
    {
        perror ("Error creating socket\n");
        exit (1);
    }

    connectionFD = serverConnection(socketFD);
    if (connectionFD < 0)
    {
        perror ("Error establishing connection \n");
        exit (1);
    }

    ret = read(connectionFD, buffer, sizeof(buffer));
    if (ret < 0)
    {
        perror ("Error reading from connection \n");
        exit (1);
    }
    else {
        while (ret != 0) {
            write(1, buffer, ret);
            read(connectionFD, buffer, buff_size);
        }
    }

    closeConnection (connectionFD);
    deleteSocket (socketFD, id);
}
