#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <errno.h>


#define buff_size 256


void error_and_exit (char *msg) {
    perror(msg);
    exit(1);
}

int main() {
    if (mknod("pipe", S_IFIFO, 0) < 0) error_and_exit("Error mknod\n");
    int fd = open("pipe", O_WRONLY | O_NONBLOCK);
    if (fd < 0 && errno == ENXIO) {
        printf("Esperando a un lector...\n");
        while ((fd = open("pipe", O_WRONLY)) == -1 && errno == ENXIO) {}
        // Si se pudo abrir la pipe, mostrar mensaje de éxito
        if (fd != -1) printf("Lector encontrado. Pipe abierta.\n");
    }
    else if (fd < 0) error_and_exit("Error open\n");

    char buff[buff_size];
    unsigned int n = read(0, buff, buff_size);
    while (n != 0) {
        write(fd, buff, n);
        read(0, buff, buff_size);
    }
}
