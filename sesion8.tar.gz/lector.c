#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>


#define buff_size 256


void error_and_exit (char *msg) {
  perror(msg);
  exit(1);
}

int main() {
    if (mknod("pipe", S_IFIFO, 0) < 0) error_and_exit("Error mknod");
    int fd = open("pipe", O_RDONLY);

    char buff[buff_size];
    unsigned int n = read(fd, buff, buff_size);
    while (n != 0) {
        write(1, buff, n);
        read(fd, buff, buff_size);
    }
}
