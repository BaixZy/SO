#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include "socketMng.h"

#define buff_size 256


void error_and_exit (char *msg) {
    perror(msg);
    exit(1);
}

int main() {
    int connectionFD;
    int ret;
    char buffer[buff_size];
    char * id = "socket1";

    connectionFD = clientConnection (id);
    if (connectionFD < 0)
    {
        perror ("Error establishing connection\n");
        exit (1);
    }

    ret = write(connectionFD, buffer, strlen(buffer));
    if (ret < 0)
    {
        perror ("Error writing on connection\n");
        exit (1);
    }

    closeConnection (connectionFD);
}
