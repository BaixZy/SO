#include <unistd.h>
#include <stdio.h>
#include <string.h>


int main() {
    int n;
    read(0, &n, sizeof(int));
    char buff[64];
    sprintf(buff, "%d\n", n);
    write(1, buff, strlen(buff));
}
