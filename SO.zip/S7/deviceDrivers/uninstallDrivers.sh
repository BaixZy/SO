#!/bin/bash
sudo rmmod myDriver1
sudo rmmod myDriver2
