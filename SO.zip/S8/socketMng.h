
int createSocket (char *);
int serverConnection (int );
int clientConnection (char *);
int deleteSocket (int, char *);
int closeConnection (int);

